COLLABORATIVE PASSWORDS MANAGER
Created by Nils Laumaill�
Copyright 2009 Nils Laumaill�

Homepage : https://sourceforge.net/projects/communitypasswo/
Help : https://sourceforge.net/projects/communitypasswo/forums/forum/1016282
Support : https://sourceforge.net/projects/communitypasswo/support

HOW TO INSTALL cPassMan?
	- Create a database (for example cpassman)
	- Import file "cpassman_db_creation.sql" into the database
	- Customize file "settings.php"
	- Copy and paste file "settings.php" into directory called "/includes/"
	- Upload directory "/passman/" into your website
	- Delete folder "install"
	
FIRST CONNECTION
	- Open your web browser
	- Open cPassMan. By default: http://your_address/cpassman
	- Get connected using account "admin" (password is "admin").